import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { TaskService} from 'src/app/services/task.service';
import { Task } from 'src/app/models/TaskModel';


@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})

export class ViewTaskComponent implements OnInit {
  tasksList: Task[];
  tasks;
  taskSearchForm;
  taskLookups;
  hasTasks: boolean = false;

  constructor(private taskService: TaskService,
    private fb: FormBuilder) { }    
  
  ngOnInit() {
    this.taskSearchForm = this.fb.group({
      taskName: [null],
      priorityFrom: [null],
      priorityTo: [null],
      parentTaskId: [null],
      startDate: [null],
      endDate: [null]
    });

    this.getTasks();
  }

  getTasks() {
    this.taskService.getAll().subscribe(value => {
      this.tasksList = this.tasks = value;
      this.hasTasks = this.tasks.length > 0;
    });
  }

  searchTasks() {
    let searchTerms = this.taskSearchForm.value;
    
    this.tasks = this.tasksList
    .filter(task => searchTerms.taskName ? task.taskName.toUpperCase().startsWith(searchTerms.taskName.toUpperCase()) : true)
      .filter(task => searchTerms.priorityFrom ? task.priority >= searchTerms.priorityFrom : true)
      .filter(task => searchTerms.priorityTo ? task.priority <= searchTerms.priorityTo : true)
      .filter(task => searchTerms.parentTaskId ? task.parentTaskId == searchTerms.parentTaskId : true)
      .filter(task => searchTerms.startDate ? task.startDate >= searchTerms.startDate : true)
      .filter(task => searchTerms.endDate ? task.endDate <= searchTerms.endDate : true);
      this.hasTasks = this.tasks.length > 0;
  }



  endTask(task) 
  {    
    this.taskService.endTask(task).subscribe
    (
      () => {alert("Task ended successfully"); this.getTasks();}
    );
  }


  
  IsEnable(task)
  {
   if (task.isTaskEnded) 
    return true;
   else
    return false;
  }

  toolTip(task)
  {
   if (task.isTaskEnded) 
    return 'Task Already Ended'
   else
   return 'End Task'
  }
  
}



