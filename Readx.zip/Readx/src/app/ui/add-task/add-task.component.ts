import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { TaskService} from 'src/app/services/task.service';
import { Task } from 'src/app/models/TaskModel';


@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {
  
  submitted = false;
  taskForm;   

  constructor(private formBuilder: FormBuilder, private taskService: TaskService, private router: Router)
  {
    
  }

  ngOnInit() 
  { 
      this.taskForm = this.formBuilder.group({
      taskName: [null, Validators.required],
      priority: [25],
      parentTaskId: [null],
      startDate: [null, Validators.required],
      endDate: [null]
    });

  }

  addTask() {

     this.submitted = true;
    if (this.taskForm.invalid) 
    {
      return;
    }

    this.taskService.create(this.taskForm.value) 
      .subscribe(value =>
        {
        alert('Task Added!')          
        this.router.navigate(["/view-task"])
        });

  }

  resetForm() {
    this.taskForm = {};
    this.submitted = false;
  }


}