import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { TaskService} from 'src/app/services/task.service';
import * as FORMATAR from 'moment';

@Component({
  selector: 'app-update-task',
  templateUrl: './update-task.component.html',
  styleUrls: ['./update-task.component.css']
})
export class UpdateTaskComponent implements OnInit {

  askLookups;
  taskForm: FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder,
    private taskService: TaskService,
    private router: Router,
    private route: ActivatedRoute) {
  }

  ngOnInit() {

    this.taskForm = this.fb.group({
      taskId: [null],
      taskName: [null, Validators.required],
      priority: [0],
      parentTaskId: [null],
      startDate: [null, Validators.required],
      endDate: [null]
    });
    
    this.route.params
      .pipe(switchMap(params => this.taskService.getById(params["id"])))
      .subscribe(value => {
        this.taskForm.patchValue({
          ...value,
          startDate: FORMATAR(value.startDate).format("YYYY-MM-DD"),
          endDate: FORMATAR(value.endDate).format("YYYY-MM-DD")
        });
      });
  }


  updateTask() {
    this.submitted = true;
    if (this.taskForm.invalid) {
      return;
    }
    this.taskService.update(this.taskForm.value)
      .subscribe(value => this.router.navigate(["/view-task"]));
  }

}
