import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ApiService } from './api.service';
import { Task } from 'src/app/models/TaskModel';

@Injectable()
export class TaskService {
  constructor(private apiService: ApiService) { }

  create(task: Task): Observable<any> {
    return this.apiService.post("Task/SaveTask", task);   
  }

  update(task: Task): Observable<any> {
    return this.apiService.put("Task/UpdateTask", task);
  }

  getAll(): Observable<any> {
    return this.apiService.get("Task/GetAll")
      .pipe(map((tasks: Array<any>) => tasks.map(task => this.mapTask(task))));
  }

  getById(taskId: number): Observable<any> {
      return this.apiService.get("Task/GetById", new HttpParams().set("id", taskId.toString()))
      .pipe(map(task => this.mapTask(task)));
  } 

  endTask(task: Task): Observable<any> {
    return this.apiService.put("Task/EndTask", task);
  }

  private mapTask(task): Task {
    return {
      taskId: task.TaskId,
      parentTaskId: task.ParentTaskId,
      taskName: task.TaskName,
      priority: task.Priority,            
      startDate: task.StartDate,
      endDate: task.EndDate,
      isTaskEnded: task.isTaskEnded
    };
  }
}
