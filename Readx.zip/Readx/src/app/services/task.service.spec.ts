import { HttpClientModule } from '@angular/common/http';
import { TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { of } from 'rxjs';

import { TaskService } from 'src/app/services/task.service';
import { ApiService } from 'src/app/services/api.service';

import { lstTasks } from 'src/app/mock/mocktasks';
import { Task } from 'src/app/models/TaskModel';

  describe('TaskService', () => {

    beforeEach(() => {
      TestBed.configureTestingModule
      ({
        imports: [HttpClientModule],
        providers: [TaskService, ApiService]
      });

   spyOn(ApiService.prototype, 'get').and.returnValue(of([
        { taskId: 1, taskName: "MocktaskX", priority: 50, parentTaskId: 1,  startDate: new Date(2018, 12, 12), endDate: new Date(2019, 12, 12), isTaskEnded: 0 },
        { taskId: 2, taskName: "MocktaskY", priority: 75, parentTaskId: 2,  startDate: new Date(2018, 12, 12), endDate: new Date(2019, 12, 12), isTaskEnded: 0 },
        { taskId: 3, taskName: "MocktaskZ", priority: 90, parentTaskId: 3,  startDate: new Date(2018, 12, 12), endDate: new Date(2019, 12, 12), isTaskEnded: 1 }]));
    });


    it('should be created', inject([TaskService], (service: TaskService) => {
      expect(service).toBeTruthy();
    }));
    
  });