import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AddTaskComponent } from './ui/add-task/add-task.component';
import { ViewTaskComponent } from './ui/view-task/view-task.component';
import { UpdateTaskComponent } from './ui/update-task/update-task.component';

import { PipePipe } from './pipes/pipe.pipe';
import { DirectiveDirective } from './directives/directive.directive';

import { TaskService } from './services/task.service';
import { ApiService } from './services/api.service';


const appRoutes: Routes = [
  { path: 'add-task', component: AddTaskComponent } , 
  { path: 'view-task', component: ViewTaskComponent } ,
  { path: 'update-task/:id', component: UpdateTaskComponent } 
];


@NgModule({
  declarations: [
    AppComponent,
    AddTaskComponent,
    ViewTaskComponent,
    UpdateTaskComponent,
    PipePipe,
    DirectiveDirective
  ],
  imports: [
    BrowserModule, 
    FormsModule, 
    ReactiveFormsModule, 
    HttpClientModule, 
    RouterModule.forRoot(appRoutes)
  ],
  providers: [TaskService, ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
