import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { TaskService} from 'src/app/services/task.service';
import { Task } from 'src/app/models/TaskModel';


@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})

export class ViewTaskComponent implements OnInit {
  tasksList;
  tasks;
  taskSearchForm;

  constructor(private taskService: TaskService, private fb: FormBuilder) { }    
  
  ngOnInit() {
    this.taskSearchForm = this.fb.group({
      taskName: [null],
      priorityFrom: [null],
      priorityTo: [null],
      parentTaskId: [null],
      startDate: [null],
      endDate: [null]
    });

    this.getTasks();
  }

  getTasks() {
    this.taskService.getAll().subscribe(value => {
      this.tasksList = this.tasks = value;
    }, error => {
      // this.tasksList = [{"taskId":1,"parentTaskId":1,"taskName":"testTaskA","priority":25,"startDate":"2019-03-03T22:44:01.12","endDate":"2019-03-03T22:44:01.12","isTaskEnded":0},{"taskId":2,"parentTaskId":1,"taskName":"testTaskB","priority":75,"startDate":"2019-03-03T22:44:23.327","endDate":"2019-03-23T22:44:23.327","isTaskEnded":0},{"taskId":1002,"parentTaskId":1,"taskName":"Task4","priority":25,"startDate":"2019-03-05T00:00:00","endDate":"2019-03-14T00:00:00","isTaskEnded":0},{"taskId":2002,"parentTaskId":1,"taskName":"Test","priority":96,"startDate":"2019-03-06T00:00:00","endDate":"2019-03-30T00:00:00","isTaskEnded":0},{"taskId":2003,"parentTaskId":6,"taskName":"Task4","priority":41,"startDate":"2019-03-07T00:00:00","endDate":"2019-03-29T00:00:00","isTaskEnded":0},{"taskId":1002,"parentTaskId":1,"taskName":"Task4","priority":25,"startDate":"2019-03-05T00:00:00","endDate":"2019-03-14T00:00:00","isTaskEnded":0},{"taskId":2002,"parentTaskId":1,"taskName":"Test","priority":96,"startDate":"2019-03-06T00:00:00","endDate":"2019-03-30T00:00:00","isTaskEnded":0},{"taskId":2003,"parentTaskId":6,"taskName":"Task4","priority":41,"startDate":"2019-03-07T00:00:00","endDate":"2019-03-29T00:00:00","isTaskEnded":1}];
      this.tasksList = [];
      this.tasks = JSON.parse(JSON.stringify(this.tasksList));
    });
  }

  searchTasks() {
    let searchTerms = this.taskSearchForm.value;
    
    this.tasks = this.tasksList
      .filter(task => searchTerms.taskName ? task.taskName.toUpperCase().startsWith(searchTerms.taskName.toUpperCase()) : true)
      .filter(task => searchTerms.priorityFrom ? task.priority >= searchTerms.priorityFrom : true)
      .filter(task => searchTerms.priorityTo ? task.priority <= searchTerms.priorityTo : true)
      .filter(task => searchTerms.parentTaskId ? task.parentTaskId == searchTerms.parentTaskId : true)
      .filter(task => searchTerms.startDate ? task.startDate >= searchTerms.startDate : true)
      .filter(task => searchTerms.endDate ? task.endDate <= searchTerms.endDate : true);
  }

  endTask(task) {    
    this.taskService.endTask(task).subscribe(() => {
      alert("Task ended successfully");
      this.getTasks();
    });
  }
}



