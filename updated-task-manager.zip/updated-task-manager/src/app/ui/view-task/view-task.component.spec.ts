import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
//import {APP_BASE_HREF} from '@angular/common';
import { of } from 'rxjs';

import { ViewTaskComponent } from './view-task.component';
import { TaskService } from '../../services/task.service';
import { ApiService } from '../../services/api.service';
import { lstTasks } from '../../mock/mocktasks';
import { Task } from '../../models/TaskModel';


describe('ViewTaskComponent', () => {
  let component: ViewTaskComponent;
  let fixture: ComponentFixture<ViewTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule, RouterTestingModule],      
      declarations: [ViewTaskComponent],
      providers: [TaskService, ApiService]      
    })
    .compileComponents();
    spyOn(TaskService.prototype, 'getAll').and.returnValue(of(lstTasks));
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should get all tasks - view', () => {
    component.getTasks();    
    expect(component.tasksList).toEqual(lstTasks);
  });
  
  
});
