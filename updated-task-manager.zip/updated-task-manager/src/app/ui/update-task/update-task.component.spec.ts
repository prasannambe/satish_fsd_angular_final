import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';

import { UpdateTaskComponent } from './update-task.component';
import { ApiService } from './../../services/api.service';
import { TaskService } from '../../services/task.service';


describe('UpdateTaskComponent', () => {
  let component: UpdateTaskComponent;
  let fixture: ComponentFixture<UpdateTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule, RouterTestingModule],
      declarations: [ UpdateTaskComponent ],
      providers: [TaskService, ApiService]      
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('form invalid when empty', () => {
    expect(component.taskForm.valid).toBeFalsy();
  });


  it('task name field validity', () => {
    let errors = {};
    let taskName = component.taskForm.controls['taskName'];
    errors = taskName.errors || {};
    expect(errors['required']).toBeTruthy(); 
  });


  it('form valid when submitted', () => {
    expect(component.taskForm.valid).toBeFalsy();
    component.taskForm.controls['taskName'].setValue("Update Karma Test");
    component.taskForm.controls['startDate'].setValue("2018-12-12");
    component.taskForm.controls['endDate'].setValue("2019-12-12");
    expect(component.taskForm.valid).toBeTruthy();
  });



});
