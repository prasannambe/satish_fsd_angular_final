import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { AddTaskComponent } from './add-task.component';
import { ApiService } from './../../services/api.service';
import { TaskService } from '../../services/task.service';


describe('AddTaskComponent', () => {
  let component: AddTaskComponent;
  let fixture: ComponentFixture<AddTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, HttpClientModule, RouterTestingModule],
      declarations: [ AddTaskComponent ],      
      providers: [TaskService, ApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form invalid when empty', () => {
    expect(component.taskForm.valid).toBeFalsy();
  });

  it('task name field validity', () => {
    let errors = {};
    let taskName = component.taskForm.controls['taskName'];
    errors = taskName.errors || {};
    expect(errors['required']).toBeTruthy(); 
  });


  it('form valid when submitted', () => {
    expect(component.taskForm.valid).toBeFalsy();
    component.taskForm.controls['taskName'].setValue("Add Karma Test");
    component.taskForm.controls['startDate'].setValue("2018-12-12");
    component.taskForm.controls['endDate'].setValue("2019-12-12");
    expect(component.taskForm.valid).toBeTruthy();
  });


});
