export class Task {
    taskId: number;
    parentTaskId: number;
        taskName: string;   
        priority: number;        
        startDate: Date;
        endDate: Date;
        isTaskEnded: number;
   constructor() {
    }
}
