

import { Task } from "../models/TaskModel";

export const lstTasks: Task[] = 
[
    { taskId: 1, taskName: "MocktaskX", priority: 50, parentTaskId: 1,  startDate: new Date(2018, 12, 12), endDate: new Date(2019, 12, 12), isTaskEnded: 0 },
    { taskId: 2, taskName: "MocktaskY", priority: 75, parentTaskId: 2,  startDate: new Date(2018, 12, 12), endDate: new Date(2019, 12, 12), isTaskEnded: 0 },
    { taskId: 3, taskName: "MocktaskZ", priority: 90, parentTaskId: 3,  startDate: new Date(2018, 12, 12), endDate: new Date(2019, 12, 12), isTaskEnded: 1 }
];